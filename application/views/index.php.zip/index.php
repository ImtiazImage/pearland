
<style>

	
	.caro-home {

		margin-top: 4% !important;

	}

	.home_slider .container-fluid{
	}

	.hom-head{

		padding: 0px !important;

		margin-bottom: 0px !important;

	}

	.hom-top {
		transition: all 0.5s ease;
		background: #1e68ac;
		box-shadow: none;
	}

	.top-ser {
		/*display: none;*/
	}

	.dmact .top-ser {
		display: block;
	}

	.caro-home {
		margin-top: 90px;
		float: left;
		width: 100%;
	}

	.carousel-item:before {
		background: none;
	}
</style>
<style>
	/*homepage_slider*/
	.home_slider{
		padding: 20px 0px 20px 0px;
	}
	.home_slider .owl-nav,.home_slider .owl-dots {
		display: none;
	}
	.home_slider .eve-box div:nth-child(2){
		padding: 10px 5px 5px 15px;
	}
	.home_slider .eve-box div:nth-child(2) h4{
		padding-bottom: 0px !important;
	}
	.home_slider .eve-box div:nth-child(3) {
		width: 100%;
		padding: 10px 15px 10px 15px;
	}
	.home_slider .pro-eve-box{
		margin: 5px !important;
	}
	.home_slider .us-ppg-com{
		padding-top: 0px !important;
	}
	.mt-15{
		margin-top: 15px !important;
	}
	.home_slider .us-ppg-blog .pro-eve-box p {
		font-size: 12px;
		margin: 0px;
		line-height: 14px;
		margin-bottom: 6px;
		position: absolute;
		margin-top: -200px;
		background: #3aa372;
		color: #fff;
		padding: 3px 8px;
		font-weight: 500;
		border-radius: 50px;
	}
	
	/*--========== NEWS & MAGAZINE  =========--*/
	.news-top-menu{
		margin-top: 60px;
		background: #000000;
		float: none;
		width: 100%;
	}
	.news-menu{float: left;width: 100%;}
	.news-menu ul{
		margin: 0 auto;
		display: table;
	}
	.news-menu ul li{
		float: left;
	}
	.news-menu ul li a{
		color: #eaeaeb;
		font-size: 14px;
		padding: 10px 12px;
		display: inline-block;
		font-weight: 400;
		position: relative;
		border-bottom: 2px solid #0b0b0c;
	}
	.news-menu ul li a:after{
		content: '';
		position: absolute;
		width: 1px;
		height: 12px;
		background: #515156;
		right: 0px;
		top: 15px;
	}
	.news-menu ul li a.act{
		border-bottom: 2px solid #b71d16;
		color: #ffffff;
		font-weight: 500;
		background: #010101;
	}
	.news-menu ul li a:hover{
		border-bottom: 2px solid #dc4e41;
		/* color: #dc4e41; */
	}
	.news-hom-ban{
		float: left;
		width: 100%;
		text-align: center;
		background: #161e24;
		padding: 45px 0px;
		color: #fff;
		position: relative;
	}
	.news-hom-ban:before{
		content: '';
		position: absolute;
		width: 100%;
		height: 100%;
		left: 0px;
		top: 0px;
		right: 0px;
		bottom: 0px;
		background: url('../images/face.jpg');
		background-size: 240px;
		opacity: 0.3;
	}
	.news-hom-ban-inn{
		position: relative;
	}
	.news-hom-ban-inn h1{
		font-size: 40px;
		font-weight: 600;
	}
	.news-hom-ban-inn h1 b{/* font-weight: 700; */color: #fff;background: #b71d16;padding: 0px 15px;border-radius: 2px;}
	.news-hom-ban-inn p{
		font-size: 16px;
		font-weight: 400;
		margin-bottom: 0px;
	}
	.news-last{float: left;width: 100%;margin-bottom: 90px;}
	.news-hom-ban-sli{
		float: left;
		width: 100%;overflow: hidden;
	}
	.news-hom-ban-sli-inn{}
	.news-hom-ban-sli-inn ul{
		position: relative;
	}
	.news-hom-ban-sli-inn ul li{
		float: left;
		width: 20%;
	}
	@media screen and (max-width:768px){
		.news-menu ul{
			white-space: nowrap;
			overflow: hidden;
			overflow-x: auto;
			-webkit-overflow-scrolling: touch;
			-ms-overflow-style: -ms-autohiding-scrollbar;
			/* height: 50px; */
			display: block;
		}
		.news-menu ul li{
			float: initial;
			display: contents;
		}
	}
	@media screen and (max-width:980px){
		.news-top-menu {
			margin-top: 55px;
		}
	}
	.news-rhs-cate{
		float: left;
		width: 100%;
		margin: 0 0 30px 0;
	}
	.news-rhs-cate h4{}
	.news-rhs-cate ul{}
	.news-rhs-cate ul li{
		margin-bottom: 8px;
	}
	.news-rhs-cate ul li a{
		background: url(<?= base_url() ?>assets/images/home4.jpg);
		display: block;
		padding: 15px 30px;
		border-radius: 5px;
		position: relative;
		color: #fff;
		font-size: 18px;
		z-index: 0;
		background-position: -41px -464px;
	}
	.news-rhs-cate ul li:nth-child(1) a{background-position: -41px -464px;}
	.news-rhs-cate ul li:nth-child(2) a{background-position: -41px -669px;}
	.news-rhs-cate ul li:nth-child(3) a{background-position: -41px -923px;}
	.news-rhs-cate ul li:nth-child(4) a{background-position: -41px -991px;}
	.news-rhs-cate ul li:nth-child(5) a{background-position: -41px -962px;}
	.news-rhs-cate ul li:nth-child(6) a{background-position: -284px -878px;}
	.news-rhs-cate ul li:nth-child(7) a{background-position: 0px 0px;}
	.news-rhs-cate ul li:nth-child(8) a{background-position: 0px 0px;}
	.news-rhs-cate ul li:nth-child(9) a{background-position: 0px 0px;}
	.news-rhs-cate ul li:nth-child(10) a{background-position: 0px 0px;}
	.news-rhs-cate ul li:nth-child(11) a{background-position: 0px 0px;}
	.news-rhs-cate ul li:nth-child(12) a{background-position: 0px 0px;}
	.news-rhs-cate ul li:nth-child(13) a{background-position: 0px 0px;}
	.news-rhs-cate ul li:nth-child(14) a{background-position: 0px 0px;}
	.news-rhs-cate ul li:nth-child(15) a{background-position: 0px 0px;}
	.news-rhs-cate ul li:nth-child(16) a{background-position: 0px 0px;}
	.news-rhs-cate ul li:nth-child(17) a{background-position: 0px 0px;}
	.news-rhs-cate ul li:nth-child(18) a{background-position: 0px 0px;}
	.news-rhs-cate ul li a:before{
		content: '';
		position: absolute;
		width: 100%;
		height: 100%;
		left: 0px;
		top:0px;
		right: 0px;
		bottom: 0px;
		background: #0000006b;
		border-radius: 5px;
	}
	.news-rhs-cate ul li a:after{
		content: 'trending_flat';
		color: #fff;
		font-size: 24px;
		right: 30px;
		top: 13px;
		transition: all 0.5s ease;
	}
	.news-rhs-cate ul li a:hover:after{

		right: 25px;
	}
	.news-rhs-cate ul li a span{
		width: 28px;
		height: 28px;
		background: #e50c0c;
		display: inline-block;
		text-align: center;
		padding: 2px;
		line-height: 26px;
		border-radius: 50px;
		margin-right: 10px;
		color: #fff;
		font-weight: 500;
		position: relative;
		font-size: 15px;
	}
	.news-rhs-cate ul li a b{position: relative;font-weight: 500;}
	.hom-eve-lhs-3 {
		float: left;
		width: 100%;
	}
</style>


<section>
	<div class="home_slider">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="home-city">
						<ul>
							<li>
								<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
									<ol class="carousel-indicators">
										<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
										<li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
										<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
									</ol>
									<div class="carousel-inner">
										<div class="carousel-item active">
											<div class="hcity">
												<div>
													<img src="https://bizbookdirectorytemplate.com/images/services/95787pexels-asad-photo-maldives-1450363.jpg" alt="">
												</div>
												<div>
													<img src="<?= base_url() ?>/assets/images/services/1.jpg" alt="">
													<h4>Hotels And Resorts</h4>
													<p>By : Pearland Admin</p>
													<div class="list-rat-all"> 
														<b>NEWS</b>
													</div>
												</div> <a href="<?= base_url() ?>news_details" class="fclick">&nbsp;</a>
											</div>
										</div>
										<div class="carousel-item">
											<div class="hcity">
												<div>
													<img src="http://new.pearland411.com//assets/images/services/8.jpg" alt="">
												</div>
												<div>
													<img src="<?= base_url() ?>/assets/images/services/1.jpg" alt="">
													<h4>Hotels And Resorts</h4>
													<p>By : Pearland Admin</p>
													<div class="list-rat-all"> 
														<b>NEWS</b>
													</div>
												</div> <a href="<?= base_url() ?>news_details" class="fclick">&nbsp;</a>
											</div>
										</div>
										<div class="carousel-item">
											<div class="hcity">
												<div>
													<img src="http://new.pearland411.com//assets/images/services/19.jpg" alt="">
												</div>
												<div>
													<img src="<?= base_url() ?>/assets/images/services/1.jpg" alt="">
													<h4>Hotels And Resorts</h4>
													<p>By : Pearland411 Admin</p>
													<div class="list-rat-all">
														<b>BUSINESS</b>
													</div>
												</div> <a href="<?= base_url() ?>listing_details_n" class="fclick">&nbsp;</a>
											</div>
										</div>
									</div>
								</div>
								
							</li>
							<li>
								<div class="hcity">
									<div>
										<img src="<?= base_url() ?>/assets/images/services/9.png" alt="">
									</div>
									<div>
										<img src="<?= base_url() ?>/assets/images/services/20356s7.jpeg" alt="">
										<h4>Automobiles</h4>
										<p>By : Pearland411 Admin</p>
										<div class="list-rat-all">
											<b>BUSINESS</b>
										</div>
									</div><a href="<?= base_url() ?>listing_details_n" class="fclick">&nbsp;</a>
								</div>
							</li>
							<li>
								<div class="hcity">
									<div>
										<img src="<?= base_url() ?>/assets/images/services/19.jpg" alt="">
									</div>
									<div>
										<img src="<?= base_url() ?>/assets/images/services/20356s7.jpeg" alt="">
										<h4>Wedding halls</h4>
										<p>By : Pearland411 Admin</p>
										<div class="list-rat-all">
											<b>BUSINESS</b>
										</div>
									</div> <a href="<?= base_url() ?>listing_details_n" class="fclick">&nbsp;</a>
								</div>
							</li>
							<li>
								<div class="hcity">
									<div>
										<img src="<?= base_url() ?>/assets/images/services/8.jpg" alt="">
									</div>
									<div>
										<img src="<?= base_url() ?>/assets/images/services/445234.jpg" alt="">
										<h4>Digital products</h4>
										<p>By : Pearland411 Admin</p>
										<div class="list-rat-all"> 
											<b>MARKETING</b>
										</div>
									</div> <a href="<?= base_url() ?>listing_details_n class="fclick">&nbsp;</a>
								</div>
							</li>
							<li>
								<div class="hcity">
									<div>
										<img src="<?= base_url() ?>/assets/images/services/2.jpeg" alt="">
									</div>
									<div>
										<img src="<?= base_url() ?>/assets/images/services/20356s7.jpeg" alt="">
										<h4>Real Estate</h4>
										<p>By : Pearland411 Admin</p>
										<div class="list-rat-all">
											<b>BUSINESS</b>
										</div>
									</div> <a href="<?= base_url() ?>listing_details_n" class="fclick">&nbsp;</a>
								</div>
							</li>
						</ul>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</section>

<!-- START -->
<section>
	<div class="str">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="ban-ati-com ads-all-list"> 
						<?php
						if($hpbsl){
						?>
						<a href="<?= base_url($hpbsl->ad_link) ?>">
							<span>Ad</span>
							<img src="<?=  $hpbsl->ad_photo; ?>" height="80" alt="">
						</a>
						<?php
						} else {
						?>
						<a href="#">
							<span>Ad</span>
							<img src="http://www.pearland411.com/graphic/banner.jpg" height="80" alt="">
						</a>						
						<?php
						}
						?>
					</div>
				</div>
				<div class="col-md-6">
					<div class="ban-ati-com ads-all-list"> 
					<?php
						if($hpbsr){
						?>
						<a href="<?= base_url($hpbsr->ad_link) ?>">
							<span>Ad</span>
							<img src="<?=  $hpbsr->ad_photo; ?>" height="80" alt="">
						</a>
						<?php
						} else {
						?>
						<a href="#">
							<span>Ad</span>
							<img src="http://www.pearland411.com/graphic/banner.jpg" height="80" alt="">
						</a>						
						<?php
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- End -->

<!-- START -->
<section>
	<div class="str">
		<div class="container">
			<div class="row">
				<div class="home-tit">
					<h2><span>Feature Business</span> in Pearland411</h2>
					<p>List your business here and make it featured Business</p>
				</div>
				<div class="hom-event">
					<div class="hom-eve-com hom-eve-lhs">
						<div class="hom-eve-lhs-1 col-md-4">
							<div class="eve-box">
								<div>
									<a href="<?= base_url() ?>event_details_n">
										<img src="<?= base_url() ?>assets/images/events/1.png" alt=""> 
                    <span><b>Dec 31</b></span>
									</a>
								</div>
								<div>
									<h4>
                     <a href="<?= base_url() ?>event_details_n">Online Marketers Meet-Up</a>
                  </h4>
									<span class="addr">London, UK</span>
									<span class="pho">6622442200</span>
								</div>
								<div>
									<div class="auth">
										<img src="<?= base_url() ?>assets/images/user/1.png" alt=""> <b>Hosted by</b>
										<br>
										<h4>Directory Finder</h4>
										<a target="_blank" href="profile.html" class="fclick"></a>
									</div>
								</div>
							</div>
						</div>
						<div class="hom-eve-lhs-2 col-md-4">
							<ul>
								<li>
									<div class="eve-box-list">
										<img src="<?= base_url() ?>assets/images/events/3.jpeg" alt="">
										<h4 title="Lunar New Year 2020">Lunar New Year 2020</h4>
											<p>Celebrate as the sights, sounds and aromas of A</p> <span>Jan <b> 07</b></span>
											<a href="<?= base_url() ?>event_details_n" class="fclick"></a>
									</div>
								</li>
								<li>
									<div class="eve-box-list">
										<img src="<?= base_url() ?>assets/images/events/4.jpg" alt="">
										<h4 title="Car Fest 2020">Car Fest 2020</h4>
											<p>Celebrate as the sights, sounds and aromas of A</p> <span>Jan   <b> 10</b></span>
											<a href="<?= base_url() ?>event_details_n" class="fclick"></a>
									</div>
								</li>
								<li>
									<div class="eve-box-list">
										<img src="<?= base_url() ?>assets/images/events/5.jpg" alt="">
										<h4 title="Poway Winter Festival">Poway Winter Festival</h4>
											<p>Celebrate as the sights, sounds and aromas of A</p> <span>Jan  <b> 18</b></span>
											<a href="<?= base_url() ?>event_details_n" class="fclick"></a>
									</div>
								</li>
								<li>
									<div class="eve-box-list">
										<img src="<?= base_url() ?>assets/images/events/5.jpg" alt="">
										<h4 title="Poway Winter Festival">Poway Winter Festival</h4>
											<p>Celebrate as the sights, sounds and aromas of A</p> <span>Jan  <b> 18</b></span>
											<a href="<?= base_url() ?>event_details_n" class="fclick"></a>
									</div>
								</li>
								<li>
									<div class="eve-box-list">
										<img src="<?= base_url() ?>assets/images/events/5.jpg" alt="">
										<h4 title="Poway Winter Festival">Poway Winter Festival</h4>
											<p>Celebrate as the sights, sounds and aromas of A</p> <span>Jan  <b> 18</b></span>
											<a href="<?= base_url() ?>event_details_n" class="fclick"></a>
									</div>
								</li>
									
							</ul>
						</div>
						<div class="hom-eve-lhs-2 col-md-4">
							<div class="filt-com lhs-ads">
								<ul>
									<li>
										<div class="ads-box">
										<?php
										if($fbr1){
										?>
										<a href="<?= base_url($fbr1->ad_link) ?>">
											<span>Ad</span>
											<img src="<?=  $fbr1->ad_photo; ?>"  alt="">
										</a>
										<?php
										} else {
										?>
										<a href="#">
											<span>Ad</span>
											<img src="http://www.pearland411.com/graphic/banner.jpg"  alt="">
										</a>						
										<?php
										}
										?>
										</div>
									</li>
									<li>
										<div class="ads-box">
										<?php
										if($fbr2){
										?>
										<a href="<?= base_url($fbr2->ad_link) ?>">
											<span>Ad</span>
											<img src="<?=  $fbr2->ad_photo; ?>" alt="">
										</a>
										<?php
										} else {
										?>
										<a href="#">
											<span>Ad</span>
											<img src="http://www.pearland411.com/graphic/banner.jpg" alt="">
										</a>						
										<?php
										}
										?>
										</div>
									</li>
									<li>
										<div class="ads-box">
										<?php
										if($fbr3){
										?>
										<a href="<?= base_url($fbr3->ad_link) ?>">
											<span>Ad</span>
											<img src="<?=  $fbr3->ad_photo; ?>" alt="">
										</a>
										<?php
										} else {
										?>
										<a href="#">
											<span>Ad</span>
											<img src="http://www.pearland411.com/graphic/banner.jpg" alt="">
										</a>						
										<?php
										}
										?>
										</div>
									</li>
									
								</ul>
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- END -->
<!-- START -->
<section>
	<div class="str str-full">
		<div class="container">
			<div class="row">
				<div class="home-tit">
					<h2>For The Community <span>By The Community</span></h2>
				</div>
				<div class="ho-popu-bod">
					<!--Top Branding Hotels-->
					<div class="col-md-4">
						<div class="hot-page2-hom-pre-head">
							<h4> <span>Business Spotlight </span></h4>
						</div>
						<div class="hot-page2-hom-pre">
							<ul>
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/1.jpg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>Royal Real Estates</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/2.jpeg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>Smith Luxury Villas</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<div class="hot-page2-hom-pre-3"> <span>2.0</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/3.jpg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>Appers Premium Independent Houses</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<div class="hot-page2-hom-pre-3"> <span>3.3</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/4.jpg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>Asian Real Estate</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/5.jpeg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>jj</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
							</ul>
						</div>
					</div>
					<div class="col-md-4">
						<div class="hot-page2-hom-pre-head">
							<h4><span>Specials & Coupons </span></h4>
						</div>
						<div class="hot-page2-hom-pre">
							<ul>
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/6.jpeg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>BizBookBusiness Directory Template</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/7.jpeg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>Sony Music</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/8.jpg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>IPM Business Software</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
							        <a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/9.png" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>Tour and Travel html Template</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<div class="hot-page2-hom-pre-3"> <span>3.7</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/10.jpg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>Smart Digital Products</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<div class="hot-page2-hom-pre-3"> <span>3.2</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
							</ul>
						</div>
					</div>
					<div class="col-md-4">
						<div class="hot-page2-hom-pre-head">
							<h4><span>News </span></h4>
						</div>
						<div class="hot-page2-hom-pre">
							<ul>
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/11.jpg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>William Chil care Hospital</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/12.jpeg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>Urban Community Hospital</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<div class="hot-page2-hom-pre-3"> <span>4.0</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/13.jpg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>Joseph Multispeciality Hospital</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/14.jpg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>Apolloo Hospitals UAE</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<div class="hot-page2-hom-pre-3"> <span>4.0</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
								<!--LISTINGS-->
								<li>
									<div class="hot-page2-hom-pre-1">
										<img src="<?= base_url() ?>assets/images/services/16.jpg" alt="">
									</div>
									<div class="hot-page2-hom-pre-2">
										<h5>Green Healthcare Hospital</h5>
										<span>No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
									</div>
									<div class="hot-page2-hom-pre-3"> <span>3.0</span>
									</div>
									<a href="<?= base_url() ?>listing_details_n" class="fclick"></a>
								</li>
								<!--LISTINGS-->
							</ul>
						</div>
					</div>
					<!--End Top Branding Hotels-->
				</div>
			</div>
		</div>
	</div>
</section>
<!-- END -->

<!-- START -->
<section>
	<div class="hom-mpop-ser">
		<div class="container">
			<div class="hom-mpop-main">
				<div class="home-tit">
					<h2>
						<span>Buy, Sell, Trade, and Rent within </span> The Pearland411                      
					</h2>
				</div>
				<div class="col-md-6">
					<div>
						<h2>Classifieds </h2>
						<!--POPULAR LISTINGS-->
						<div class="hom-mpop">
							<!--POPULAR LISTINGS IMAGE-->
							<div class="col-md-3">
								<img src="<?= base_url() ?>assets/images/listings/1.jpg" alt="" />
							</div>
							<!--POPULAR LISTINGS: CONTENT-->
							<div class="col-md-9">
								<h3>Titan Wedding Hall</h3>
								<h4>Wedding halls</h4>
								<p>Titan wedding happ, North street, No 2, Newyork, USA</p> <span class="rat-sh">5.0</span>
							</div> <a href="<?= base_url() ?>listing_details_n">&nbsp;</a>
						</div>
						<!--POPULAR LISTINGS-->
						<div class="hom-mpop">
							<!--POPULAR LISTINGS IMAGE-->
							<div class="col-md-3">
								<img src="<?= base_url() ?>assets/images/listings/2.jpg" alt="" />
							</div>
							<!--POPULAR LISTINGS: CONTENT-->
							<div class="col-md-9">
								<h3>Gill Automobiles and Services</h3>
								<h4>Automobiles</h4>
								<p>Titan wedding happ, North street, No 2, Newyork, USA</p>
							</div>
						</div>
						<!--POPULAR LISTINGS-->
						<div class="hom-mpop">
							<!--POPULAR LISTINGS IMAGE-->
							<div class="col-md-3">
								<img src="<?= base_url() ?>assets/images/listings/3.jpeg" alt="" />
							</div>
							<!--POPULAR LISTINGS: CONTENT-->
							<div class="col-md-9">
								<h3>Rolexo Villas in California</h3>
								<h4>Real Estate</h4>
								<p>28800 Orchard Lake Road, Suite 180 Farmington Hills, U.S.A.</p> <span class="rat-sh">5.0</span>
							</div><a href="<?= base_url() ?>listing_details_n">&nbsp;</a>
						</div>
						<!--POPULAR LISTINGS-->
						<div class="hom-mpop">
							<!--POPULAR LISTINGS IMAGE-->
							<div class="col-md-3">
								<img src="<?= base_url() ?>assets/images/listings/4.jpg" alt="" />
							</div>
							<!--POPULAR LISTINGS: CONTENT-->
							<div class="col-md-9">
								<h3>The Spa at Mandarin Oriental</h3>
								<h4>Hospitals</h4>
								<p>No:2, 4th Avenue, Newyork, USA, Near to Airport</p> <span class="rat-sh">4.0</span>
							</div><a href="<?= base_url() ?>listing_details_n">&nbsp;</a>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div>
						<h2>Apartments & Rentals </h2>
						<!--POPULAR LISTINGS-->
						<div class="hom-mpop">
							<!--POPULAR LISTINGS IMAGE-->
							<div class="col-md-3">
								<img src="<?= base_url() ?>assets/images/listings/5.jpeg" alt="" />
							</div>
							<!--POPULAR LISTINGS: CONTENT-->
							<div class="col-md-9">
								<h3>IPM Business Software</h3>
								<h4>Digital Products</h4>
								<p>No:2, 4th Avenue, Newyork, USA, Near to Airport</p>
							</div><a href="<?= base_url() ?>listing_details_n">&nbsp;</a>
						</div>
						<!--POPULAR LISTINGS-->
						<div class="hom-mpop">
							<!--POPULAR LISTINGS IMAGE-->
							<div class="col-md-3">
								<img src="<?= base_url() ?>assets/images/listings/6.jpg" alt="" />
							</div>
							<!--POPULAR LISTINGS: CONTENT-->
							<div class="col-md-9">
								<h3>Rachel Taj Hotels</h3>
								<h4>Hotels And Resorts</h4>
								<p>No:2, 4th Avenue, Newyork, USA, Near to Airport</p> <span class="rat-sh">3.0</span>
							</div><a href="<?= base_url() ?>listing_details_n">&nbsp;</a>
						</div>
						<!--POPULAR LISTINGS-->
						<div class="hom-mpop">
							<!--POPULAR LISTINGS IMAGE-->
							<div class="col-md-3">
								<img src="<?= base_url() ?>assets/images/listings/7.jpg" alt="" />
							</div>
							<!--POPULAR LISTINGS: CONTENT-->
							<div class="col-md-9">
								<h3>Joseph Multispeciality Hospital</h3>
								<h4>Hospitals</h4>
								<p>No:2, 4th Avenue, Newyork, USA, Near to Airport</p>
							</div> <a href="<?= base_url() ?>listing_details_n">&nbsp;</a>
						</div>
						<!--POPULAR LISTINGS-->
						<div class="hom-mpop">
							<!--POPULAR LISTINGS IMAGE-->
							<div class="col-md-3">
								<img src="<?= base_url() ?>assets/images/listings/8.jpeg" alt="" />
							</div>
							<!--POPULAR LISTINGS: CONTENT-->
							<div class="col-md-9">
								<h3>Green Healthcare Hospital</h3>
								<h4>Hospitals</h4>
								<p>No:2, 4th Avenue, Newyork, USA, Near to Airport</p> <span class="rat-sh">3.0</span>
							</div> <a href="<?= base_url() ?>listing_details_n">&nbsp;</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
	<!-- END -->

<!-- START -->
<section>
	<div class="event-body">
		<div class="container">
			<div class="home-tit">
		    <h2><span>Feature Events</span> in city                        </h2>
		    <p>lacinia viverra lectus. Fusce imperdiet ullamcorper metus eu fringilla.</p>
			</div>
			<div class="us-ppg-com">
				<ul id="intseres">
					<li>
						<div class="eve-box">
							<div>
								<a href="<?= base_url() ?>event_details_n">
									<img src="<?= base_url() ?>assets/images/events/1.png" alt=""> 
		              <span>Dec<b>28</b></span>
								</a>
							</div>
							<div>
								<h4>
		              <a href="<?= base_url() ?>event_details_n">New year celebration 2020</a>
		            </h4>
								<span class="addr">No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
								<span class="pho">98765498465</span>
							</div>
							<div>
								<div class="auth">
									<img src="<?= base_url() ?>assets/images/user/1.png" alt=""> <b>Hosted by</b>
									<br>
									<h4>Directory Finder</h4>
									<a target="_blank" href="<?= base_url() ?>event_details_n" class="fclick"></a>
								</div>
							</div>
						</div>
					</li>
		      <li>
						<div class="eve-box">
							<div>
								<a href="<?= base_url() ?>event_details_n">
									<img src="<?= base_url() ?>assets/images/events/2.jpg" alt=""> 
		              <span>Dec<b>28</b></span>
								</a>
							</div>
							<div>
								<h4>
			            <a href="<?= base_url() ?>event_details_n">Online Marketers Meet-Up</a>
			        	</h4>
								<span class="addr">No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
								<span class="pho">98765498465</span>
							</div>
							<div>
								<div class="auth">
									<img src="<?= base_url() ?>assets/images/user/2.jpeg" alt=""> <b>Hosted by</b>
									<br>
									<h4>Directory Finder</h4>
									<a target="_blank" href="<?= base_url() ?>event_details_n" class="fclick"></a>
								</div>
							</div>
						</div>
					</li>
		      <li>
						<div class="eve-box">
							<div>
								<a href="<?= base_url() ?>event_details_n">
									<img src="<?= base_url() ?>assets/images/events/3.jpeg" alt=""> 
		              <span>Dec<b>28</b></span>
								</a>
							</div>
							<div>
								<h4>
		              <a href="<?= base_url() ?>event_details_n">Lunar New Year 2020</a>
		            </h4>
								<span class="addr">No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
								<span class="pho">98765498465</span>
							</div>
							<div>
								<div class="auth">
									<img src="<?= base_url() ?>assets/images/user/3.jpg" alt=""> <b>Hosted by</b>
									<br>
									<h4>Directory Finder</h4>
									<a target="_blank" href="<?= base_url() ?>event_details_n" class="fclick"></a>
								</div>
							</div>
						</div>
					</li>
		      
		      <li>
						<div class="eve-box">
							<div>
								<a href="<?= base_url() ?>event_details_n">
									<img src="<?= base_url() ?>assets/images/events/1.png" alt=""> 
		              <span>Dec<b>28</b></span>
								</a>
							</div>
							<div>
								<h4>
		              <a href="<?= base_url() ?>event_details_n">New year celebration 2020</a>
		            </h4>
								<span class="addr">No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
								<span class="pho">98765498465</span>
							</div>
							<div>
								<div class="auth">
									<img src="<?= base_url() ?>assets/images/user/1.png" alt=""> <b>Hosted by</b>
									<br>
									<h4>Directory Finder</h4>
									<a target="_blank" href="<?= base_url() ?>event_details_n" class="fclick"></a>
								</div>
							</div>
						</div>
					</li>
		                <li>
						<div class="eve-box">
							<div>
								<a href="<?= base_url() ?>event_details_n">
									<img src="<?= base_url() ?>assets/images/events/2.jpg" alt=""> 
		              <span>Dec<b>28</b></span>
								</a>
							</div>
							<div>
								<h4>
		              <a href="<?= base_url() ?>event_details_n">Online Marketers Meet-Up</a>
		            </h4>
								<span class="addr">No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
								<span class="pho">98765498465</span>
							</div>
							<div>
								<div class="auth">
									<img src="<?= base_url() ?>assets/images/user/2.jpeg" alt=""> <b>Hosted by</b>
									<br>
									<h4>Directory Finder</h4>
									<a target="_blank" href="<?= base_url() ?>event_details_n" class="fclick"></a>
								</div>
							</div>
						</div>
					</li>
		      <li>
						<div class="eve-box">
							<div>
								<a href="<?= base_url() ?>event_details_n">
									<img src="<?= base_url() ?>assets/images/events/3.jpeg" alt=""> 
		              <span>Dec<b>28</b></span>
								</a>
							</div>
							<div>
								<h4>
		              <a href="<?= base_url() ?>event_details_n">Lunar New Year 2020</a>
		          	</h4>
								<span class="addr">No:2, 4th Avenue,  Newyork, USA, Near to Airport</span>
								<span class="pho">98765498465</span>
							</div>
							<div>
								<div class="auth">
									<img src="<?= base_url() ?>assets/images/user/3.jpg" alt=""> <b>Hosted by</b>
									<br>
									<h4>Directory Finder</h4>
									<a target="_blank" href="<?= base_url() ?>event_details_n" class="fclick"></a>
								</div>
							</div>
						</div>
					</li>
		      
				</ul>
			</div>
		</div>
	</div>
</section>
<!--END-->

<!-- START -->
<section class="video-section">
	<div class="hom-mpop-ser">
		<div class="container">
			<div class="hom-mpop-main">
				<div class="home-tit">
					<h2>
						<span>Video Directory </span>                
					</h2>
				</div>

				<div class="row">
					<div class="col-md-6">
						<div class="video-box">
							<div class="video-link">
								<img class="thumbnail" src="http://new.pearland411.com/assets/images/events/2.jpg">
							</div>
							<a href=""><h4>Between The Trees Business Talk - 070 - Jessica Munselle</h4></a>
							<p>Jessica Munselle, Director of Community Development at 5Point Credit Union | Team Lead for The Chamber’s C.A.R.E.S. Committee visits with JJ Hollie about updates on the 2022 Volunteer Appreciation Luncheon.</p>
						</div>
						<div class="ban-ati-com ads-all-list"> 
						<?php
						if($afl){
						?>
						<a href="<?= base_url($afl->ad_link) ?>">
							<span>Ad</span>
							<img src="<?=  $afl->ad_photo; ?>" alt="">
						</a>
						<?php
						} else {
						?>
						<a href="#">
							<span>Ad</span>
							<img src="http://www.pearland411.com/graphic/banner.jpg" height="80" alt="">
						</a>						
						<?php
						}
						?>
					</div>
					</div>
					<div class="col-md-6">
						<div>
							<!--POPULAR LISTINGS-->
							<div class="hom-mpop">
								<!--POPULAR LISTINGS IMAGE-->
								<div class="col-md-3">
									<div class="video-link">
										<img src="<?= base_url() ?>assets/images/listings/5.jpeg" alt="" />
									</div>
								</div>
								<!--POPULAR LISTINGS: CONTENT-->
								<div class="col-md-9">
									<h3>IPM Business Software</h3>
									<h4>Digital Products</h4>
									<p>No:2, 4th Avenue, Newyork, USA, Near to Airport</p>
								</div><a href="<?= base_url() ?>listing_details_n">&nbsp;</a>
							</div>
							<!--POPULAR LISTINGS-->
							<div class="hom-mpop">
								<!--POPULAR LISTINGS IMAGE-->
								<div class="col-md-3">
									<div class="video-link">
										<img src="<?= base_url() ?>assets/images/listings/6.jpg" alt="" />
									</div>
								</div>
								<!--POPULAR LISTINGS: CONTENT-->
								<div class="col-md-9">
									<h3>Rachel Taj Hotels</h3>
									<h4>Hotels And Resorts</h4>
									<p>No:2, 4th Avenue, Newyork, USA, Near to Airport</p> <span class="rat-sh">3.0</span>
								</div><a href="<?= base_url() ?>listing_details_n">&nbsp;</a>
							</div>
							<!--POPULAR LISTINGS-->
							<div class="hom-mpop">
								<!--POPULAR LISTINGS IMAGE-->
								<div class="col-md-3">
									<div class="video-link">
										<img src="<?= base_url() ?>assets/images/listings/7.jpg" alt="" />
									</div>
								</div>
								<!--POPULAR LISTINGS: CONTENT-->
								<div class="col-md-9">
									<h3>Joseph Multispeciality Hospital</h3>
									<h4>Hospitals</h4>
									<p>No:2, 4th Avenue, Newyork, USA, Near to Airport</p>
								</div> <a href="<?= base_url() ?>listing_details_n">&nbsp;</a>
							</div>
							<!--POPULAR LISTINGS-->
							<div class="hom-mpop">
								<!--POPULAR LISTINGS IMAGE-->
								<div class="col-md-3">
									<div class="video-link">
										<img src="<?= base_url() ?>assets/images/listings/8.jpeg" alt="" />
									</div>
								</div>
								<!--POPULAR LISTINGS: CONTENT-->
								<div class="col-md-9">
									<h3>Green Healthcare Hospital</h3>
									<h4>Hospitals</h4>
									<p>No:2, 4th Avenue, Newyork, USA, Near to Airport</p> <span class="rat-sh">3.0</span>
								</div> <a href="<?= base_url() ?>listing_details_n">&nbsp;</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<style>
	
	.video-link {
		display:block; 
		overflow:visible;
		position:relative;
    background-color:#bbb;
    cursor: pointer;
	}

	.video-link .thumbnail {
		width:100%;
		object-fit: contain;
		object-position: center;
	}

	.video-link::after {
		content:"";
		display:block;
		position:absolute;
		top:0;
		left:0;
		height:100%;
		width:100%;
		background-image:url("http://new.pearland411.com/assets/images/icon/play_icon.png");
		background-position: center center;
		background-repeat:no-repeat;
		background-size:20%;
    filter: drop-shadow(0 0 10px rgba(0,0,0,.4));
	}

	.video-link:hover::after {
    background-size:22%;
    -webkit-transition: background-size .2s ease-in-out;
    -moz-transition: background-size .2s ease-in-out;
    -o-transition: background-size .2s ease-in-out;
    transition: background-size .2s ease-in-out;
	}
	.video-box{
		border: 1px solid #fff;
		padding: 11px;
	}
	.video-section .hom-mpop{
		margin-bottom: 0px !important;
	}



</style>